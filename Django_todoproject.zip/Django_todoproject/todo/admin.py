from django.contrib import admin

from todo.models import TodoModel

# Register your models here.

admin.site.register(TodoModel)
