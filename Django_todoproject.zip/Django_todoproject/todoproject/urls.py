from django.contrib import admin
from django.urls import path
from django.urls.conf import include

urlpatterns = [
    path('admin/', admin.site.urls),
    # adminという文字以外は以下に飛ぶ（空白の為）
    path('', include('todo.urls'))
]
