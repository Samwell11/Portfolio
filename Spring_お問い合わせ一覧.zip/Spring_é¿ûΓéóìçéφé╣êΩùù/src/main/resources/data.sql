INSERT INTO inquiry(name, email, contents, created)
VALUES('Ethan', 'sample@example.com', 'Hello', '2019-11-12 08:34:19');
INSERT INTO inquiry(name, email, contents, created)
VALUES('Emma', 'sample2@example.com', 'GoodMorning', '2019-12-18 12:10:52');
INSERT INTO inquiry(name, email, contents, created)
VALUES('William', 'sample3@example.com', 'GoodEvening', '2019-12-18 15:10:52');

INSERT INTO survey(age, satisfaction, comment, created)
VALUES(23, 5, 'Good!', '2019-01-03 11:02:35');
INSERT INTO survey(age, satisfaction, comment, created)
VALUES(47, 4, 'Excellent', '2019-02-18 22:35:54');
INSERT INTO survey(age, satisfaction, comment, created)
VALUES(47, 4, 'Excellent', '2019-02-18 22:35:54');
